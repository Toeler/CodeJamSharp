﻿#define START_THIS_FILE

using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace CodeJamSharp {
	internal static class $fileinputname$ {
#if START_THIS_FILE
		private static void Main() {
#else
		private static void NotMain() {
#endif
			new CodeJamProblem(new CodeJamConfig() {
				InputFile = "$fileinputname$Test.in",
				//InputFile = "$fileinputname$-small-attempt0.in",
				//InputFile = "$fileinputname$-large.in",
				Solver = (testCase, cache) => {
					return "TODO";
				}
			});
		}
	}
}
